#!/usr/bin/env zsh
##############################################################################
# File: ./lib/commands/storage.zsh
# Project: Usenet Media Stack
# Description: JBOD storage pool management
# Author: Joseph Lanzone <mailto:j3lanzone@gmail.com>
# Created: 2025-05-24
# Modified: 2025-05-24
# Version: 1.0.0
# License: MIT
#
# Manages JBOD (Just a Bunch of Disks) storage configuration for the media
# stack. Handles adding/removing drives, checking disk health, and managing
# mount points for optimal media storage distribution.
##############################################################################

##############################################################################
#                              INITIALIZATION                                #
##############################################################################

# Load core functions
SCRIPT_DIR="${0:A:h}"
PROJECT_ROOT="${SCRIPT_DIR:h:h}"
source "${SCRIPT_DIR:h}/core/common.zsh"
source "${SCRIPT_DIR:h}/core/init.zsh"

# Ensure config is loaded
load_stack_config || die 1 "Failed to load configuration"

##############################################################################
#                             STORAGE FUNCTIONS                              #
##############################################################################

#=============================================================================
# Function: show_storage_help
# Description: Display storage management help
#
# Arguments:
#   None
#
# Returns:
#   0 - Always succeeds
#=============================================================================
show_storage_help() {
    cat <<'HELP'
🗄️  Storage Management

USAGE
    usenet storage <action> [options]

ACTIONS
    status             Show current storage configuration and health
    add <path>         Add a new drive to the storage pool
    remove <path>      Remove drive from storage pool (data preserved)
    health             Check health status of all drives
    balance            Rebalance data across available drives
    mount              Mount all configured drives
    unmount            Safely unmount all drives

OPTIONS
    --force, -f        Force operation without confirmation
    --verbose, -v      Show detailed output
    --dry-run, -n      Show what would be done without executing

EXAMPLES
    Check storage status:
        $ usenet storage status
        
    Add a new drive:
        $ usenet storage add /mnt/disk2
        
    Check drive health:
        $ usenet storage health
        
    Balance storage usage:
        $ usenet storage balance --verbose

NOTES
    • All drives must be pre-mounted in /mnt/ directory
    • JBOD configuration distributes content across drives
    • Use 'balance' after adding new drives for optimal distribution
    • Health checks use smartctl if available

HELP
}

#=============================================================================
# Function: get_storage_config
# Description: Get current storage pool configuration
#
# Returns:
#   0 - Configuration found
#   1 - No configuration exists
#=============================================================================
get_storage_config() {
    local config_file="${PROJECT_ROOT}/config/storage.conf"
    
    if [[ -f "$config_file" ]]; then
        return 0
    else
        return 1
    fi
}

#=============================================================================
# Function: show_storage_status
# Description: Display current storage pool status
#
# Arguments:
#   None
#
# Returns:
#   0 - Status shown successfully
#   1 - Error getting status
#=============================================================================
show_storage_status() {
    info "Storage Pool Status"
    print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    local config_file="${PROJECT_ROOT}/config/storage.conf"
    
    if [[ ! -f "$config_file" ]]; then
        warning "No storage configuration found"
        info "Run 'usenet storage add <path>' to add your first drive"
        return 1
    fi
    
    # Read storage configuration
    local drive_count=0
    local total_space=0
    local used_space=0
    
    while IFS= read -r drive_path; do
        [[ -z "$drive_path" || "$drive_path" =~ ^# ]] && continue
        
        if [[ -d "$drive_path" ]]; then
            ((drive_count++))
            
            # Get disk usage (convert from KB to GB)
            local usage=$(df -k "$drive_path" 2>/dev/null | tail -1)
            if [[ -n "$usage" ]]; then
                local size_kb=$(echo "$usage" | awk '{print $2}')
                local used_kb=$(echo "$usage" | awk '{print $3}')
                local avail_kb=$(echo "$usage" | awk '{print $4}')
                local percent=$(echo "$usage" | awk '{print $5}')
                
                local size_gb=$((size_kb / 1024 / 1024))
                local used_gb=$((used_kb / 1024 / 1024))
                local avail_gb=$((avail_kb / 1024 / 1024))
                
                total_space=$((total_space + size_gb))
                used_space=$((used_space + used_gb))
                
                print "  ${COLOR_GREEN}✓${COLOR_RESET} $drive_path"
                print "    Size: ${size_gb}GB | Used: ${used_gb}GB (${percent}) | Available: ${avail_gb}GB"
            else
                print "  ${COLOR_RED}✗${COLOR_RESET} $drive_path (not accessible)"
            fi
        else
            print "  ${COLOR_RED}✗${COLOR_RESET} $drive_path (not found)"
        fi
    done < "$config_file"
    
    print ""
    print "Total Pool: ${drive_count} drives, ${total_space}GB total, ${used_space}GB used"
    
    # Show mount status
    info "Media directories:"
    for dir in downloads media; do
        local dir_path="${PROJECT_ROOT}/$dir"
        if [[ -d "$dir_path" ]]; then
            local mount_info=$(df -h "$dir_path" 2>/dev/null | tail -1 | awk '{print $5 " used on " $6}')
            print "  $dir: $mount_info"
        fi
    done
}

#=============================================================================
# Function: add_storage_drive
# Description: Add a new drive to the storage pool
#
# Arguments:
#   $1 - Drive path to add
#
# Returns:
#   0 - Drive added successfully
#   1 - Error adding drive
#=============================================================================
add_storage_drive() {
    local drive_path="$1"
    
    if [[ -z "$drive_path" ]]; then
        error "Drive path required"
        print "Usage: usenet storage add <path>"
        return 1
    fi
    
    # Validate drive path
    if [[ ! -d "$drive_path" ]]; then
        error "Directory does not exist: $drive_path"
        return 1
    fi
    
    # Check if drive is mounted
    if ! mountpoint -q "$drive_path" 2>/dev/null; then
        warning "Path is not a mount point: $drive_path"
        if ! confirm "Continue anyway?"; then
            return 1
        fi
    fi
    
    # Create storage config if it doesn't exist
    local config_file="${PROJECT_ROOT}/config/storage.conf"
    local config_dir="${PROJECT_ROOT}/config"
    
    if [[ ! -d "$config_dir" ]]; then
        mkdir -p "$config_dir"
    fi
    
    if [[ ! -f "$config_file" ]]; then
        cat > "$config_file" <<EOF
# Usenet Media Stack Storage Configuration
# Each line represents a drive in the JBOD pool
# Lines starting with # are ignored
#
# Created: $(date)
EOF
    fi
    
    # Check if drive already exists in config
    if grep -Fxq "$drive_path" "$config_file" 2>/dev/null; then
        warning "Drive already in pool: $drive_path"
        return 1
    fi
    
    # Add drive to config
    echo "$drive_path" >> "$config_file"
    success "Added drive to storage pool: $drive_path"
    
    # Update Docker Compose bind mounts
    info "Updating Docker Compose configuration..."
    update_compose_mounts
    
    info "Drive added successfully. Consider running 'usenet storage balance' to redistribute content."
    return 0
}

#=============================================================================
# Function: remove_storage_drive
# Description: Remove a drive from the storage pool
#
# Arguments:
#   $1 - Drive path to remove
#
# Returns:
#   0 - Drive removed successfully
#   1 - Error removing drive
#=============================================================================
remove_storage_drive() {
    local drive_path="$1"
    
    if [[ -z "$drive_path" ]]; then
        error "Drive path required"
        print "Usage: usenet storage remove <path>"
        return 1
    fi
    
    local config_file="${PROJECT_ROOT}/config/storage.conf"
    
    if [[ ! -f "$config_file" ]]; then
        error "No storage configuration found"
        return 1
    fi
    
    # Check if drive exists in config
    if ! grep -Fxq "$drive_path" "$config_file"; then
        error "Drive not found in pool: $drive_path"
        return 1
    fi
    
    warning "Removing drive from storage pool: $drive_path"
    warning "This will NOT delete data on the drive"
    if ! confirm "Continue with removal?"; then
        return 1
    fi
    
    # Remove from config (create temp file to avoid issues)
    local temp_file=$(mktemp)
    grep -Fxv "$drive_path" "$config_file" > "$temp_file"
    mv "$temp_file" "$config_file"
    
    success "Removed drive from storage pool: $drive_path"
    
    # Update Docker Compose bind mounts
    info "Updating Docker Compose configuration..."
    update_compose_mounts
    
    return 0
}

#=============================================================================
# Function: check_storage_health
# Description: Check health status of all drives in the pool
#
# Arguments:
#   None
#
# Returns:
#   0 - Health check completed
#   1 - Error during health check
#=============================================================================
check_storage_health() {
    info "Storage Health Check"
    print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    local config_file="${PROJECT_ROOT}/config/storage.conf"
    
    if [[ ! -f "$config_file" ]]; then
        error "No storage configuration found"
        return 1
    fi
    
    local healthy_drives=0
    local total_drives=0
    
    while IFS= read -r drive_path; do
        [[ -z "$drive_path" || "$drive_path" =~ ^# ]] && continue
        
        ((total_drives++))
        print "Checking: $drive_path"
        
        # Check if mounted and accessible
        if [[ -d "$drive_path" ]] && [[ -r "$drive_path" ]] && [[ -w "$drive_path" ]]; then
            print "  ${COLOR_GREEN}✓${COLOR_RESET} Mount point accessible"
            ((healthy_drives++))
            
            # Try to get device name for SMART check
            local device=$(df "$drive_path" | tail -1 | awk '{print $1}' | sed 's/[0-9]*$//')
            
            if command -v smartctl >/dev/null 2>&1 && [[ -b "$device" ]]; then
                local smart_status=$(smartctl -H "$device" 2>/dev/null | grep "SMART overall-health" | awk '{print $NF}')
                if [[ "$smart_status" == "PASSED" ]]; then
                    print "  ${COLOR_GREEN}✓${COLOR_RESET} SMART status: PASSED"
                else
                    print "  ${COLOR_YELLOW}⚠${COLOR_RESET} SMART status: $smart_status"
                fi
            else
                print "  ${COLOR_BLUE}ℹ${COLOR_RESET} SMART check not available"
            fi
        else
            print "  ${COLOR_RED}✗${COLOR_RESET} Drive not accessible"
        fi
        
        print ""
    done < "$config_file"
    
    if [[ $healthy_drives -eq $total_drives ]]; then
        success "All $total_drives drives are healthy"
    else
        warning "$((total_drives - healthy_drives)) of $total_drives drives have issues"
    fi
    
    return 0
}

#=============================================================================
# Function: update_compose_mounts
# Description: Update Docker Compose with current storage configuration
#
# Arguments:
#   None
#
# Returns:
#   0 - Configuration updated
#   1 - Error updating configuration
#=============================================================================
update_compose_mounts() {
    # This would integrate with the docker-compose.yml to update bind mounts
    # For now, just show what would be updated
    info "Storage mount configuration updated"
    info "Restart services to apply changes: usenet restart"
    return 0
}

##############################################################################
#                               MAIN FUNCTION                               #
##############################################################################

#=============================================================================
# Function: main
# Description: Main entry point for storage management
#
# Arguments:
#   $@ - All command line arguments
#
# Returns:
#   Exit code from the executed action
#=============================================================================
main() {
    local action="${1:-help}"
    shift || true
    
    case "$action" in
        status)
            show_storage_status
            ;;
        add)
            add_storage_drive "$@"
            ;;
        remove)
            remove_storage_drive "$@"
            ;;
        health)
            check_storage_health
            ;;
        balance)
            info "Storage balancing not yet implemented"
            return 1
            ;;
        mount|unmount)
            info "Mount/unmount operations not yet implemented"
            return 1
            ;;
        help|--help|-h)
            show_storage_help
            ;;
        *)
            error "Unknown storage action: $action"
            show_storage_help
            return 1
            ;;
    esac
}

# Run if called directly
if [[ "${ZSH_ARGZERO:-${(%):-%x}}" == "${0}" ]]; then
    main "$@"
fi

# vim: set ts=4 sw=4 et tw=80: